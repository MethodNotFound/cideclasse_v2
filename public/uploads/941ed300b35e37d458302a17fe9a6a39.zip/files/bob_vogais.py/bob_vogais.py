#ignora eu

inp = input()

chars = list(inp)

counter = 0
for char in chars:
    if char == "a" or char == "e" or char == "i" or char == "o" or char == "u":
        counter += 1
    if char == "A" or char == "E" or char == "I" or char == "O" or char == "U":
        counter += 1

print(counter)

